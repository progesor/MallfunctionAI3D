Mallfunction AI3D Studio -- Devir Paketi, 15 Ekim 2026

Kaynak repo: https://github.com/progesor/MallfunctionAI3D
Aktif branch: feat/desktop-studio-foundation

Dosyalar:
1. AI3D_STATUS_REPORT_2026-10-15.md -- gercek durum ve CI blokaji
2. AI3D_ROADMAP_2026-10-15.md -- Unity URP/HDRP oncelikli plan
3. AI3D_UNITY_URP_HDRP_EXPORT_SPEC_2026-10-15.md -- FBX + packed mask + prefab importer
4. AI3D_HANDOVER_2026-10-15.md -- yeni sohbet devir talimati

Yeni sohbette ilk olarak AI3D_HANDOVER_2026-10-15.md belgesini oku.
Bu ZIP dosyasi sadece dokumantasyon snapshot'idir; mevcut Studio kaynak kodu icin yukaridaki repo'yu kullan.
